"""
Panels package - Paneles modernos de la aplicación
"""
from smart_reports.ui.panels.modern_dashboard import ModernDashboard

__all__ = ['ModernDashboard']
