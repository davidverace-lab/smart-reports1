"""
Diálogos de la aplicación
"""
from smart_reports.ui.dialogs.user_management_dialog import UserManagementDialog

__all__ = ['UserManagementDialog']
