"""
VentanaPrincipalView - SOLO INTERFAZ VISUAL (UI)
Patrón Android Studio: Esta clase es como el XML (solo vista)
La lógica está en los Controllers (como Java en Android)

ARQUITECTURA LIMPIA:
- View (este archivo): Solo widgets y layout
- Controllers: Toda la lógica de negocio
"""
import customtkinter as ctk
from tkinter import messagebox

# Configuración e imports
from smart_reports.config.settings import UI_CONFIG, APP_NAME
from smart_reports.config.themes import HUTCHISON_COLORS
from smart_reports.config.gestor_temas import get_theme_manager
from smart_reports.database.repositories.persistence.mysql.connection import DatabaseConnection

# Controllers (LÓGICA separada - ViewModels en Android)
from smart_reports.core.controllers.database_query_controller import DatabaseQueryController
from smart_reports.core.controllers.file_import_controller import FileImportController
from smart_reports.core.controllers.reports_controller import ReportsController
from smart_reports.core.controllers.navigation_controller import NavigationController

# Components (UI - Widgets/Custom Views en Android)
from smart_reports.ui.components.navigation.barra_lateral import ModernSidebar
from smart_reports.ui.components.navigation.barra_superior import TopBar

# Menus (UI modular - Views/Fragments)
try:
    from smart_reports.ui.views.menu_dashboard import show_dashboard_menu
    from smart_reports.ui.views.menu_reportes import show_reportes_menu
    from smart_reports.ui.views.menu_configuracion import show_configuracion_menu
    from smart_reports.ui.views.menu_consultas import show_consultas_menu
    from smart_reports.ui.views.menu_actualizar import show_actualizar_menu
except ImportError as e:
    print(f"⚠️ Error importando menus: {e}")
    # Fallback functions
    def show_dashboard_menu(parent, *args, **kwargs):
        pass
    def show_reportes_menu(parent, *args, **kwargs):
        pass
    def show_configuracion_menu(parent, *args, **kwargs):
        pass
    def show_consultas_menu(parent, *args, **kwargs):
        pass
    def show_actualizar_menu(parent, *args, **kwargs):
        pass


class VentanaPrincipalView:
    """
    Vista principal - SOLO INTERFAZ (patrón Android)

    Esta clase SOLO maneja:
    - Creación de widgets
    - Layout y posicionamiento
    - Navegación entre paneles

    La LÓGICA está en los Controllers
    """

    def __init__(self, root, username="Admin", user_role="Administrador"):
        """
        Inicializar vista principal

        Args:
            root: Ventana raíz de Tkinter
            username: Nombre del usuario
            user_role: Rol del usuario
        """
        self.root = root
        self.root.title("SMART REPORTS - INSTITUTO HUTCHISON PORTS")
        self.root.geometry("1400x900")

        # Información del usuario
        self.username = username
        self.user_role = user_role

        # Theme Manager
        self.theme_manager = get_theme_manager()

        # Track current view for theme refresh
        self.current_view = None

        # Configurar appearance de customtkinter
        appearance = self.theme_manager.get_theme_mode()
        ctk.set_appearance_mode(appearance)
        ctk.set_default_color_theme("dark-blue")

        # === CONTROLLERS (LÓGICA SEPARADA) ===
        self._initialize_controllers()

        # === UI COMPONENTS ===
        self._create_interface()

        # Registrar callback para cambios de tema
        self.theme_manager.register_callback(self._on_theme_changed)

    def _initialize_controllers(self):
        """Inicializar todos los controllers (lógica separada)"""

        # Base de datos
        self.db = DatabaseConnection()
        self.conn = None
        self.cursor = None

        try:
            self.conn = self.db.connect()
            self.cursor = self.db.get_cursor()
        except Exception as e:
            messagebox.showerror(
                "Error de Conexión",
                f"No se pudo conectar a la base de datos:\n{str(e)}\n\n"
                "La aplicación continuará pero algunas funciones no estarán disponibles."
            )

        # Controllers (lógica separada de la UI)
        self.db_controller = DatabaseQueryController(self.conn, self.cursor) if self.conn else None
        self.file_controller = FileImportController(self.db)
        self.reports_controller = ReportsController(self.conn, self.cursor) if self.conn else None
        self.nav_controller = NavigationController()

        # Verificar base de datos (sin bloquear si falla)
        if self.db_controller:
            try:
                success, message = self.db_controller.verify_database_tables()
                if not success:
                    print(f"⚠ Advertencia BD: {message}")
                    # NO mostrar messagebox que bloquea la UI
            except Exception as e:
                print(f"⚠ No se pudo verificar BD: {e}")

    def _create_interface(self):
        """Crear interfaz de usuario (SOLO UI)"""
        theme = self.theme_manager.get_current_theme()

        # Container principal - SIN MÁRGENES GRISES
        self.main_container = ctk.CTkFrame(
            self.root,
            fg_color=theme['colors']['background'],
            corner_radius=0
        )
        self.main_container.pack(fill='both', expand=True, padx=0, pady=0)

        # === SIDEBAR (Navegación lateral) ===
        navigation_callbacks = {
            'dashboard': self.show_dashboard,
            'consultas': self.show_consultas,
            'importacion': self.show_importacion,
            'reportes': self.show_reportes,
            'configuracion': self.show_configuracion,
        }

        self.sidebar = ModernSidebar(
            self.main_container,
            navigation_callbacks,
            theme_change_callback=self._handle_theme_change
        )
        self.sidebar.pack(side='left', fill='y')

        # === RIGHT FRAME (TopBar + Content) - SIN MÁRGENES ===
        right_frame = ctk.CTkFrame(
            self.main_container,
            fg_color=theme['colors']['background'],
            corner_radius=0
        )
        right_frame.pack(side='left', fill='both', expand=True, padx=0, pady=0)

        # TopBar (Barra superior) - SIN MÁRGENES
        self.top_bar = TopBar(
            right_frame,
            username=self.username,
            user_role=self.user_role
        )
        self.top_bar.pack(side='top', fill='x', padx=0, pady=0)

        # Content Area (Área de contenido principal) - SIN MÁRGENES
        self.content_area = ctk.CTkFrame(
            right_frame,
            fg_color=theme['colors']['background'],
            corner_radius=0
        )
        self.content_area.pack(side='top', fill='both', expand=True, padx=0, pady=0)

        # Mostrar dashboard por defecto
        self.show_dashboard()
        self.sidebar.set_active('dashboard')

    # ==================== NAVEGACIÓN ENTRE PANELES ====================

    def _clear_content(self):
        """Limpiar área de contenido"""
        for widget in self.content_area.winfo_children():
            widget.destroy()

    def show_dashboard(self):
        """Mostrar panel de Dashboards"""
        self._clear_content()
        self.current_view = 'dashboard'
        self.nav_controller.navigate_to('dashboard', None)

        try:
            print("\n" + "="*60)
            print("📊 CARGANDO DASHBOARD")
            print("="*60)
            print(f"Content area: {self.content_area}")
            print(f"Tema actual: {self.theme_manager.get_theme_mode()}")

            # Usar módulo de menú (lógica separada)
            panel = show_dashboard_menu(
                self.content_area,
                self.conn,
                self.username,
                self.user_role
            )

            print(f"Panel creado: {panel}")
            print(f"Panel type: {type(panel)}")

            if panel:
                # CRÍTICO: SIN MÁRGENES para eliminar espacios grises
                panel.pack(fill='both', expand=True, padx=0, pady=0)
                print(f"Panel empaquetado: {panel.winfo_ismapped()}")
                print(f"Panel size: {panel.winfo_width()}x{panel.winfo_height()}")
                print("✅ Dashboard cargado y empaquetado exitosamente")
            else:
                print("❌ Panel de dashboard es None")
                self._show_placeholder("Dashboard", "Error al cargar dashboard")
        except Exception as e:
            print(f"❌ ERROR CARGANDO DASHBOARD: {e}")
            import traceback
            traceback.print_exc()
            self._show_placeholder("Error en Dashboard", str(e))

    def show_actualizar(self):
        """Mostrar panel de Actualización/Cruce de Datos"""
        self._clear_content()
        self.current_view = 'actualizar'
        self.nav_controller.navigate_to('actualizar', None)

        # Usar módulo de menú (lógica separada)
        panel = show_actualizar_menu(
            self.content_area,
            self.conn,
            self.file_controller
        )
        panel.pack(fill='both', expand=True, padx=20, pady=20)

    def show_importacion(self):
        """Mostrar panel de Importación de Datos"""
        self._clear_content()
        self.current_view = 'importacion'
        self.nav_controller.navigate_to('importacion', None)

        try:
            print("📥 Cargando Importación...")
            # Importar PanelImportacionDatos
            from smart_reports.ui.views.configuracion.panel_importacion_datos import PanelImportacionDatos

            # Crear panel de importación
            panel = PanelImportacionDatos(
                self.content_area,
                db_connection=self.conn
            )
            if panel:
                panel.pack(fill='both', expand=True)
                print("✅ Importación cargada exitosamente")
            else:
                print("❌ Panel de importación es None")
                self._show_placeholder("Importación", "Error al cargar importación")
        except Exception as e:
            print(f"❌ Error cargando importación: {e}")
            import traceback
            traceback.print_exc()
            self._show_placeholder("Error en Importación", str(e))

    def show_consultas(self):
        """Mostrar panel de Consultas"""
        self._clear_content()
        self.current_view = 'consultas'
        self.nav_controller.navigate_to('consultas', None)

        try:
            print("\n" + "="*60)
            print("🔍 CARGANDO CONSULTAS")
            print("="*60)

            # Usar módulo de menú (lógica separada)
            panel = show_consultas_menu(
                self.content_area,
                self.conn
            )

            print(f"Panel creado: {panel}")

            if panel:
                panel.pack(fill='both', expand=True, padx=0, pady=0)
                print("✅ Consultas cargadas y empaquetadas exitosamente")
            else:
                print("❌ Panel de consultas es None")
                self._show_placeholder("Consultas", "Error al cargar consultas")
        except Exception as e:
            print(f"❌ ERROR CARGANDO CONSULTAS: {e}")
            import traceback
            traceback.print_exc()
            self._show_placeholder("Error en Consultas", str(e))

    def show_reportes(self):
        """Mostrar panel de Reportes"""
        self._clear_content()
        self.current_view = 'reportes'
        self.nav_controller.navigate_to('reportes', None)

        try:
            print("\n" + "="*60)
            print("📄 CARGANDO REPORTES")
            print("="*60)

            # Usar módulo de menú (lógica separada)
            menu = show_reportes_menu(
                self.content_area,
                self.conn,
                self.cursor
            )

            print(f"Menú creado: {menu}")

            if menu:
                print("✅ Reportes cargados exitosamente")
            else:
                print("❌ Menú de reportes es None")
                self._show_placeholder("Reportes", "Error al cargar reportes")
        except Exception as e:
            print(f"❌ ERROR CARGANDO REPORTES: {e}")
            import traceback
            traceback.print_exc()
            self._show_placeholder("Error en Reportes", str(e))

    def show_configuracion(self):
        """Mostrar panel de Configuración"""
        self._clear_content()
        self.current_view = 'configuracion'
        self.nav_controller.navigate_to('configuracion', None)

        try:
            print("\n" + "="*60)
            print("⚙️ CARGANDO CONFIGURACIÓN")
            print("="*60)

            # Usar módulo de menú (lógica separada)
            panel = show_configuracion_menu(
                self.content_area,
                self.conn,
                self.cursor,
                self.db
            )

            print(f"Panel creado: {panel}")

            if panel:
                panel.pack(fill='both', expand=True, padx=0, pady=0)
                print("✅ Configuración cargada y empaquetada exitosamente")
            else:
                print("❌ Panel de configuración es None")
                self._show_placeholder("Configuración", "Error al cargar configuración")
        except Exception as e:
            print(f"❌ ERROR CARGANDO CONFIGURACIÓN: {e}")
            import traceback
            traceback.print_exc()
            self._show_placeholder("Error en Configuración", str(e))

    # ==================== HELPERS ====================
    # (Código de reportes movido a src/interfaces/ui/views/menus/menu_reportes.py)


    # ==================== HELPERS ====================

    def _show_error_message(self, message):
        """Mostrar mensaje de error en el content area"""
        theme = self.theme_manager.get_current_theme()

        error_frame = ctk.CTkFrame(self.content_area, fg_color='transparent')
        error_frame.pack(fill='both', expand=True)

        error_label = ctk.CTkLabel(
            error_frame,
            text=f'⚠️ {message}\n\nPor favor verifica la configuración.',
            font=('Montserrat', 18),
            text_color='#ff6b6b'
        )
        error_label.pack(expand=True)

    def _show_placeholder(self, title, message):
        """Mostrar placeholder para paneles en desarrollo"""
        theme = self.theme_manager.get_current_theme()

        placeholder_frame = ctk.CTkFrame(self.content_area, fg_color='transparent')
        placeholder_frame.pack(fill='both', expand=True)

        title_label = ctk.CTkLabel(
            placeholder_frame,
            text=f'🚧 {title}',
            font=('Montserrat', 28, 'bold'),
            text_color=HUTCHISON_COLORS['aqua_green']
        )
        title_label.pack(expand=True, pady=(0, 10))

        message_label = ctk.CTkLabel(
            placeholder_frame,
            text=message,
            font=('Montserrat', 16),
            text_color=theme['colors']['text_secondary']
        )
        message_label.pack(expand=True)

    def _handle_theme_change(self):
        """Manejar cambio de tema"""
        # El theme manager ya maneja la propagación
        # Solo necesitamos refrescar la interfaz
        pass

    def _on_theme_changed(self, theme_mode):
        """Callback cuando cambia el tema"""
        # Actualizar appearance mode de customtkinter
        appearance = "dark" if theme_mode == 'dark' else "light"
        ctk.set_appearance_mode(appearance)

        # Obtener los colores del nuevo tema
        theme = self.theme_manager.get_current_theme()

        # Refrescar colores del main container
        self.main_container.configure(fg_color=theme['colors']['background'])
        self.content_area.configure(fg_color=theme['colors']['background'])

        # Refrescar el panel actual para aplicar cambios de tema inmediatamente
        if self.current_view == 'dashboard':
            self.show_dashboard()
        elif self.current_view == 'consultas':
            self.show_consultas()
        elif self.current_view == 'importacion':
            self.show_importacion()
        elif self.current_view == 'reportes':
            self.show_reportes()
        elif self.current_view == 'configuracion':
            self.show_configuracion()


# Alias para mantener compatibilidad con código existente
MainWindow = VentanaPrincipalView
